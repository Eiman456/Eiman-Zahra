import java.util.UUID;
public class VideoCall{
    public String startCall() {
        String link="https://meet.example.com/"+UUID.randomUUID();
        System.out.println("Video call started: "+link);
        return link;
    }
}