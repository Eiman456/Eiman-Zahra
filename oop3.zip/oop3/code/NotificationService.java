import java.util.List;
public class NotificationService {
    private List<Notifiable>notifiables; //different typess of notification service through sms or email
//constructor formation
    public NotificationService(List<Notifiable>notifiables){
        this.notifiables=notifiables;
    }
//method for sending notifications
    public void sendAlert(String to, String message){
        for(Notifiable notifiable: notifiables){
    //it will handle the exceptions without stopping the system to work or to crash
            try{
                notifiable.send(to, message);
            }catch(Exception e) {
                System.err.println("Failed to send alert: " + e.getMessage());
            }
        }
    }
}