public class EmergencyAlert{
    private NotificationService notificationService;
    private static final int MAX_HEART_RATE=100; //making them static and final to set a standard
    private static final int MIN_HEART_RATE=60;
    private static final int MAX_SYSTOLIC=140;
    private static final int MIN_DIASTOLIC=60;
//constructor formation
    public EmergencyAlert(NotificationService notificationService){
        this.notificationService = notificationService;
    }
//methods for sending alert when the heart rate and blood pressure are not normal 
    public void checkVitals(int heartRate,int systolic,int diastolic){
        if(heartRate>MAX_HEART_RATE || heartRate<MIN_HEART_RATE) {
            notificationService.sendAlert("emergency@example.com","Critical heart rate: "+heartRate);
        }
        if (systolic>MAX_SYSTOLIC || diastolic<MIN_DIASTOLIC) {
            notificationService.sendAlert("emergency@example.com","Critical BP: "+systolic+"/" +diastolic);
        }
    }
}