public class Patient {
    private String name;
    private String email;
//constructor formation
    public Patient(String name, String email) {
        this.name=name;
        this.email=email;
    }
//getter
    public String getEmail(){
        return email; }
}
