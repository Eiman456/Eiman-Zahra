public interface Notifiable{
    //it defines a method for sending notifications
    void send(String to, String message);
}