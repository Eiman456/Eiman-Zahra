// Source code is decompiled from a .class file using FernFlower decompiler.
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

class EmailNotification implements Notifiable {
   private final String senderEmail = "eimanzahra456@gmail.com";
   private final String senderPassword = "ewewed@123";

   EmailNotification() {
   }

   public void sendNotification(String var1, String var2, String var3) {
      Properties var4 = new Properties();
      var4.put("mail.smtp.auth", "true");
      var4.put("mail.smtp.starttls.enable", "true");
      var4.put("mail.smtp.host", "smtp.gmail.com");
      var4.put("mail.smtp.port", "587");
      Session var5 = Session.getInstance(var4, new EmailNotification$1(this));

      try {
         MimeMessage var6 = new MimeMessage(var5);
         var6.setFrom(new InternetAddress("eimanzahra456@gmail.com"));
         var6.setRecipients(RecipientType.TO, InternetAddress.parse(var1));
         var6.setSubject(var2);
         var6.setText(var3);
         Transport.send(var6);
         System.out.println("✅ Email sent successfully!");
      } catch (MessagingException var7) {
         var7.printStackTrace();
      }

   }
}
