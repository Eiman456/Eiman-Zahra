public class SMSNotification implements Notifiable{
    //sending notifications through sms
    @Override
    public void send(String to, String message){
        if (to == null || !to.startsWith("+")){
            //throws exception when an invalid phone number is added
            throw new IllegalArgumentException("Invalid phone number: " + to);
        }
        System.out.println("SMS sent to " + to + ": " + message);
    }
}