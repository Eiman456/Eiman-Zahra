import java.util.Arrays;
public class Test{
    public static void main(String[] args){
        Notifiable email=new EmailNotification();
        Notifiable sms=new SMSNotification();
        NotificationService alerts=new NotificationService(Arrays.asList(email, sms));
    //emergency System
        EmergencyAlert emergencyAlert=new EmergencyAlert(alerts);
        emergencyAlert.checkVitals(120,150,50); // Triggers alert
        PanicButton panicButton=new PanicButton(alerts);
        panicButton.triggerEmergency();
    //reminders
        ReminderService reminders=new ReminderService(email);
        reminders.sendAppointmentReminder("patient@example.com", "2025-04-22 10:00 AM");
    //chat
        ChatServer chat=new ChatServer();
        ChatClient patient=new ChatClient("Patient", chat);
        ChatClient doctor=new ChatClient("Doctor", chat);
        patient.send("Hello, I need help.");
        doctor.send("Please check your vitals.");
    //video Call
        VideoCall video=new VideoCall();
        video.startCall();
    }
}