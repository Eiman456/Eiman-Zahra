public class ReminderService{
    private Notifiable notifiable;//reference to the notification method sms or email
//constructor formation
    public ReminderService(Notifiable notifiable){
        this.notifiable = notifiable;
    }
//method for sending appointment reminders
    public void sendAppointmentReminder(String to, String dateTime){
        String message = "Reminder: Appointment on " + dateTime;
        notifiable.send(to, message);
    }
//methods for sending reminder for taking medicine
    public void sendMedicationReminder(String to,String medication,String time){
        String message="Reminder: Take "+medication+" at "+time;
        notifiable.send(to, message);
    }
}