public class ChatClient{
    private String user;
    private ChatServer server;
//constructor forrmation
    public ChatClient(String user,ChatServer server){
        this.user=user;
        this.server=server;
    }
//method for sending msgs
    public void send(String message){
        server.sendMessage(user, message);
    }
//method for displayong msgs
    public void displayMessages(){
        System.out.println("Chat history for "+user+":");
        server.getMessages().forEach(System.out::println);
    }
}