public class PanicButton{
    private NotificationService notificationService;//it is used to send notifications when the trigered button is pressed
//constructor formation
    public PanicButton(NotificationService notificationService){
        this.notificationService = notificationService;
    }
//method to press panic botton in emergency
    public void triggerEmergency(){
        notificationService.sendAlert("emergency@example.com", "PANIC BUTTON PRESSED!");
    }
}