import java.util.ArrayList;
import java.util.List;
public class ChatServer{
    private List<String>messages=new ArrayList<>();
//this list will store all the chats
//gettter
    public List<String> getMessages(){
        return new ArrayList<>(messages);
    }
    public void sendMessage(String user,String message){
        String formatted=user + ": "+message;
        messages.add(formatted);
        System.out.println("[Chat] "+formatted);
    }
}